export class Users{
    userId?: number;
    firstName: string;
    lastname: string;
    email: string;
    contact: string;
}