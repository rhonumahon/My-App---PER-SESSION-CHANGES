import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tableFilter'
})
export class TableFilterPipe implements PipeTransform {

  transform(firstName: any[], value: string): any {
    return value ? firstName.filter(item => item.firstName === value) : firstName;
  }

}
