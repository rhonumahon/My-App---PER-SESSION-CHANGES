import { Injectable } from '@angular/core';
import { User } from './edit/user.model';

@Injectable({
  providedIn: 'root'
})
export class ContactsService {

  private contacts: User[]=[];



  constructor(){}

  setContacts(newContacts: User []){
      this.contacts=newContacts;
    }

  //  getContact( index: number){
  //    return this.contacts.find((contact)=> contact.id == index)

  //  }

   getContactsLength (){
     return this.contacts.length;
   }
}
