import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ApiService } from '../api.service';
import { ContactsService } from '../contacts.service';
import { User } from './user.model';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  contact: User;
  id: number;

  activeTab : any;
  constructor(private route: ActivatedRoute, private router: Router, private contactsService:ContactsService, private api:ApiService) { }

  ngOnInit() {
    // this.route.params.subscribe((params: Params)=> {
    //   this.id =+params ['id'];
    //   console.log(+params['id']);
    //   this.contact=this.contactsService.getContact(this.id);});
  }




}
