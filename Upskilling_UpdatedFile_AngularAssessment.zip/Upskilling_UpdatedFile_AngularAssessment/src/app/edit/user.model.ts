export class User {


    id: string;
     firstName: string;
     lastName: string;
     address: string;
   contact: string;


}
