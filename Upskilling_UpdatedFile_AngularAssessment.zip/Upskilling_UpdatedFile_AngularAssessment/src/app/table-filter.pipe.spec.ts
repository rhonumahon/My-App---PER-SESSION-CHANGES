import { TableFilterPipe } from './table-filter.pipe';

describe('TableFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TableFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
