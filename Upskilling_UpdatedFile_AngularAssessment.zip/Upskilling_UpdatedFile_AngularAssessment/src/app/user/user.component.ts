import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';
import { ContactsService } from '../contacts.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
})
export class UserComponent implements OnInit {
  id: string;
  location: string;
  activeTab: any = 'active';
  friends: any[] = [];
  editMode: boolean= false;
  form: FormGroup;
  // ids =new FormControl('', Validators.compose([Validators.required]));
  firstName = new FormControl('', Validators.compose([Validators.required, Validators.minLength(2),Validators.maxLength(30)]));
  lastName = new FormControl('', Validators.compose([Validators.required, Validators.minLength(2),Validators.maxLength(30)]));
  address = new FormControl('', Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(30)]));
  contact = new FormControl('', Validators.compose([Validators.required,Validators.minLength(2),Validators.maxLength(30)]));
  constructor(public route: ActivatedRoute, public router: Router, public formBuilder: FormBuilder, public api: ApiService, public location2: Location, private contactsService: ContactsService) {
    this.form = this.createForm(formBuilder);
    const url = this.route.snapshot;
    const id = url.params.id;
    this.id = url.params.id;
    // this.location = this.id ? url.url[2].path : url.url[1].path;
    if (id) {
      this.location = url.url[2].path;
    } else if (id == null) {
      this.location = url.url[1].path;
    }
    // add custom
    else if (id){
      this.location = url.routeConfig.path;
    }


    console.log(url);
    console.log(this.location);
    console.log(this.id);

    this.route.queryParams
      .subscribe(params => {
        console.log('params', params);
      })
  }

  createForm(formBuilder: FormBuilder){
    return formBuilder.group({
      firstName: this.firstName,
      lastName: this.lastName,
      address: this.address,
      contact: this.contact
    })
  }

  ngOnInit(): void {
    this.openUser(this.location, this.id);
    this.editUser(this.location, this.id);


  }

  openUser(loc, id){
    const data = this.api.getUser().find(item => item.id === Number(id));
    console.log('openUser', data);

    if(loc === 'view' && id){
      this.form.patchValue({
        firstName: data.firstName,
        lastName: data.lastName,
        address: data.address,
        contact: data.contact,
      })
      this.friends = data.friends;
      this.form.disable();
    }

  }

  editUser(loc, id){
    const data = this.api.getUser().find(item => item.id === Number(id));
    console.log('edit', data);

    if(loc === 'edit' && id){
      this.form.setValue({
        // ids: data.id,
        firstName: data.firstName,
        lastName: data.lastName,
        address: data.address,
        contact: data.contact,
      })
      this.friends = data.friends;
      console.log(this.form.value);
    }


  }



  back(){
    // this.router.navigate(['/sampleApp'])
    this.location2.back();
  }

  tab(event){
  this.activeTab = event;
  }

  submit() {
    if(this.location == 'edit'){
      console.log(this.form.value);
      this.api.updateUser(this.form.value,this.id);

    } else{
    const {...etc} = this.form.value;
    const friends = this.friends;
    const result = {...etc, friends};
    console.log(result);
    if(this.form.valid){
      //submit
      this.api.addUser(result);
    }



    'use strict'

    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')

    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
      .forEach(function (form) {
        form.addEventListener('submit', function (event) {
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }

          form.classList.add('was-validated')
        }, false)
      })
    }

  }

  receiveFriend(event){
    this.friends = event;
  }

}
