import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-friendship',
  templateUrl: './friendship.component.html',
  styleUrls: ['./friendship.component.css']
})
export class FriendshipComponent implements OnInit {
  @Input() currentTab;
  @Input() value: string;
  @Input() location: string;
  @Input() friends: any[] = [];
  @Output() sendFriend = new EventEmitter<any>();
  newValue: boolean;
  firstName: string;
  lastName: string;
  activeList: any[];
  inactiveList: any[];
  allList: any[];
  activeDisplay: any[];
  inactiveDisplay: any[];
  allDisplay: any[];
  data: any[];

  givenName: any;

  constructor(private api: ApiService) {
    this.data = this.api.getUser();
  }

  ngOnInit(): void {
    this.newValue = this.currentTab === "active" ? true : false;
    // console.log(this.newValue);

    this.categorizedFriends();
    setTimeout(() => {
      this.activeDisplay = this.activeList;
      this.inactiveDisplay = this.inactiveList;
      this.allDisplay = this.allList;
    }, 1000);
  }

  inputFriend(name, event) {
    this[`${name}Name`] = event.target.value;
    // console.log(event.target.value);

  }

  addFriend() {
    this.friends.push({
      firstName: this.firstName,
      lastName: this.lastName,
      isActive: this.currentTab,
    });
    this.categorizedFriends();
    this.sendFriend.emit(this.friends);



  }

  searchFriend(event) {
    this[`${this.currentTab}List`] = this[`${this.currentTab}List`].filter(
      (item) => {
        const fullName = `${item.firstName} ${item.lastName}`;
        if (fullName.toLowerCase().includes(event.target.value.toLowerCase())) {
          console.log(fullName.toLowerCase().includes(event.target.value.toLowerCase()));
          return item;

        }
      }
    );
    if (event.target.value == "") {
      this[`${this.currentTab}List`] = this[`${this.currentTab}Display`];
      console.log(event.target.value == "");
     };


  }

  erase(event){
  //   const {...etc} = this.friends;
  //   const friends = this.friends;
  //   const result = {...etc, friends};
  //  (this.friends.splice(1,1));
  //   console.log(result, event);
  //   return {result, friends, ...etc};

    // if(this.form.valid){
    //   //submit
    //   this.api.addUser(result);
  }





  categorizedFriends() {
    // this[`${this.value}List`] = this.friends.filter(item => item.isActive === this.newValue);
    // console.log(this.activeList);
    // console.log(this.inactiveList);
    this.activeList = this.friends.filter((item) => item.isActive === "active");
    this.inactiveList = this.friends.filter((item) => item.isActive === "inactive");
    this.allList = this.friends.filter((item) =>item.isActive ? "active" : "inactive");



  }


}
