import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  id: string;
  location: string;
  friends: any[] = [];
  form: FormGroup;
  
  firstName = new FormControl('', Validators.compose([Validators.required, Validators.minLength(2),Validators.maxLength(10)]));
  lastName = new FormControl('', Validators.compose([Validators.required]));
  address = new FormControl('', Validators.compose([Validators.required]));
  contact = new FormControl('', Validators.compose([Validators.required]));
  
  constructor(
    public route: ActivatedRoute, 
    public formBuilder: FormBuilder,
    private api: ApiService
  ) { 
    this.form = this.createForm(formBuilder);
    const url = this.route.snapshot;
    this.id = url.params.id;
    this.location = this.id ? url.url[2].path : url.url[1].path;
    console.log(this.location);
    console.log(this.id);
    console.log(this.firstName);

    this.route.queryParams
      .subscribe(params => {
        console.log('params', params);
      })}

      createForm(formBuilder: FormBuilder){
        return formBuilder.group({
          firstName: this.firstName,
          lastName: this.lastName,
          address: this.address,
          contact: this.contact
        })
      }

  ngOnInit() {
    // this.openUser(this.location, this.id);
    this.openUser(this.id);
  }
  
  // openUser(loc, id){
  //   const data = this.api.getUser().find(item => item.id === Number(id));
  //   console.log('openUser', data);

  //   if(loc === 'edit' && id){
  //     this.form.patchValue({
  //       firstName: data.firstName,
  //       lastName: data.lastName,
  //       address: data.address,
  //       contact: data.contact,
  //     });
  //     this.friends = data.friends;
  //     this.form.disable();
  //   }
  // }

  openUser(id){
    const data = this.api.getUser().find(item => item.id === Number(id));
    console.log('openUser', data);

    if(id){
      this.form.patchValue({
        firstName: data.firstName,
        lastName: data.lastName,
        address: data.address,
        contact: data.contact,
      });
      this.friends = data.friends;
      this.form.disable();
    }
  }

}
