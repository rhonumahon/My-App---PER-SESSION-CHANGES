import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-friends',
  templateUrl: './friends.component.html',
  styleUrls: ['./friends.component.css']
})
export class FriendsComponent implements OnInit {
@Input() value: string;
@Input() location: string;
@Input() friends: any[] = [];
@Output() sendFriend = new EventEmitter<any>();
newValue: boolean;
newValueAll: boolean;
inactivefriends: boolean;
allFriends: boolean = true;
firstName: string;
lastName: string;
id: string;
activeList: any[];
inactiveList: any[];
allFriendsList: any[];
activeDisplay: any[];
inactiveDisplay: any[];
allFriendsDisplay: any[];
viewMode = 'tab1';
  constructor(
    private api: ApiService, 
    private router: Router,
    public route: ActivatedRoute
  ) { 
    const url = this.route.snapshot;
    this.id = url.params.id;
    this.location = this.id ? url.url[2].path : url.url[1].path;
    console.log(this.location);
    console.log(this.id);
    
    this.route.queryParams
      .subscribe(params => {
        console.log('params', params);
      })
  }

  ngOnInit(): void {
    this.newValue = this.value === 'active' ? true : false;
    this.newValueAll = this.value === 'active' ? true : false;
    this.allFriends = this.value === 'active' ? true : false;
    this.inactivefriends = this.value === 'active' ? true : false;
    // this.doTask().then(val =>{
    //   console.log(val);
    // });
    this.openUser(this.id);
    this.categorizedFriends();
    setTimeout(()=>{
      this.activeDisplay = this.activeList;
      this.inactiveDisplay = this.inactiveList;
      this.allFriendsDisplay = this.allFriendsList;
    }, 1000)
  }

  
  item: any = {
    name : 'name'
  }

  oldItemData = {
    name : 'name'
  } 

 

  editModeToggle =false;
  
  edit(item: any) {
    this.editModeToggle = true;
    //this.oldItemData = this.item;
    this.oldItemData = JSON.parse(JSON.stringify(this.item)); //OK
    console.log('------ edit activate -------')
    console.log('old item:', this.oldItemData.name);
    console.log('item:', this.item.name);
  }

  saveChanges(item: any) {
    // some stuff happens
    this.editModeToggle = false;
    console.log('------ save -------')
    console.log('old item:', this.oldItemData.name);
    console.log('item:', this.item.name);
  }

  cancelEdit() {
    this.editModeToggle = false;
    this.item = this.oldItemData;
    console.log('------ cancel -------')
    console.log('old item:', this.oldItemData.name);
    console.log('item:', this.item.name);
  }

  inputFriend(name, event){
    this[`${name}Name`] = event.target.value;
  }

  addFriend(){
    this.friends.push({firstName: this.firstName, lastName: this.lastName, isActive: this.newValue});
    this.categorizedFriends();
    this.sendFriend.emit(this.friends);
  }
  
  deleteFriend(i){
    this.activeList.splice(i,1);
  }

  deleteInactive(i){
    this.inactiveList.splice(i,1);
  }

  deleteAll(i){
    this.friends.splice(i,1);
  }

  searchFriend(event){

      this[`${this.value}List`] = this[`${this.value}List`].filter(item => {
        const fullName = `${item.firstName} ${item.lastName}`
        if(fullName.toLowerCase().includes(event.target.value.toLowerCase()
        )){
          return item;
        } 
      });
    if (event.target.value === ''){
      this[`${this.value}List`] = this[`${this.value}Display`];
      
    }

  }

  categorizedFriends(){
    this[`${this.value}List`] = this.friends.filter(item => item.isActive === this.newValue);
    // console.log(this.activeList);
    // console.log(this.inactiveList);
    
    
  }

  doTask(){
    return new Promise(resolve => {
      setTimeout(() => {
        this.allFriendsList = this.api.getUser();
        console.log('delay 1000');
        resolve('done');
      }, 1000);
    })
  }

  openUser(id){
    const data = this.api.getUser().find(item => item.id === Number(id));
    console.log('openUser', data);

    if(id){
      this.friends = data.friends;
      console.log(this.friends)
    }
  }

}
